// Flappy Helicopter - Vanilla JS Canvas
(function(){
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');

  // Responsive scaling (keeps internal logic on 480x720)
  const BASE_W = 480, BASE_H = 720;
  function resize() {
    const ratio = BASE_W / BASE_H;
    const maxW = Math.min(640, canvas.parentElement.clientWidth);
    const w = maxW;
    const h = w / ratio;
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';
  }
  window.addEventListener('resize', resize);
  resize();

  // Game state
  let state = 'ready'; // 'ready' | 'playing' | 'gameover'
  let score = 0;
  let best = Number(localStorage.getItem('flappy_helicopter_best') || 0);

  // Physics
  const gravity = 0.45;
  const flapStrength = -7.5;
  const maxFall = 12;

  // Helicopter
  const heli = {
    x: BASE_W * 0.28,
    y: BASE_H * 0.5,
    vy: 0,
    r: 18,
    rot: 0,
    rotor: 0
  };

  // Buildings (obstacles)
  const buildings = [];
  const gap = 160;
  const spacing = 230;
  const speed = 2.9;
  const minTop = 80;
  const minBottom = 120;

  // Clouds for sky
  const clouds = [];
  for (let i=0;i<8;i++){
    clouds.push({
      x: Math.random()*BASE_W,
      y: Math.random()*BASE_H*0.6,
      w: 80 + Math.random()*120,
      h: 30 + Math.random()*20,
      s: 0.3 + Math.random()*0.7,
      a: 0.5 + Math.random()*0.3
    });
  }

  function resetGame() {
    state = 'ready';
    score = 0;
    heli.x = BASE_W * 0.28;
    heli.y = BASE_H * 0.5;
    heli.vy = 0;
    heli.rot = 0;
    buildings.length = 0;
    for (let i = 0; i < 4; i++) {
      spawnBuilding(BASE_W + i * spacing);
    }
    updateHUD();
  }

  function spawnBuilding(x){
    const maxOpeningCenter = BASE_H - minBottom - gap/2;
    const minOpeningCenter = minTop + gap/2;
    const center = rand(minOpeningCenter, maxOpeningCenter);
    const topH = center - gap/2;
    const bottomY = center + gap/2;
    const bottomH = BASE_H - bottomY;

    buildings.push({
      x,
      width: 90,
      topH,
      bottomY,
      bottomH,
      passed: false
    });
  }

  function rand(min, max){ return Math.random() * (max - min) + min; }

  function flap(){
    if (state === 'gameover') return;
    if (state === 'ready') { state = 'playing'; }
    heli.vy = flapStrength;
  }

  function update(){
    // Sky clouds drift
    for (let c of clouds){
      c.x -= c.s;
      if (c.x + c.w < -10){
        c.x = BASE_W + Math.random()*80;
        c.y = Math.random()*BASE_H*0.6;
        c.w = 90 + Math.random()*120;
        c.h = 30 + Math.random()*20;
        c.s = 0.3 + Math.random()*0.7;
      }
    }

    if (state === 'playing') {
      // Helicopter physics
      heli.vy = Math.min(heli.vy + gravity, maxFall);
      heli.y += heli.vy;
      heli.rot = Math.atan2(heli.vy, 6);
      heli.rotor += 0.35; // rotor spin

      // Buildings
      for (let b of buildings) b.x -= speed;

      // Recycle
      if (buildings[0].x + buildings[0].width < -10) {
        buildings.shift();
        spawnBuilding(buildings[buildings.length - 1].x + spacing);
      }

      // Scoring
      for (let b of buildings) {
        if (!b.passed && b.x + b.width < heli.x) {
          b.passed = true;
          score++;
          updateHUD();
        }
      }

      // Collisions
      if (collidesWithBounds() || collidesWithBuildings()) {
        state = 'gameover';
        best = Math.max(best, score);
        localStorage.setItem('flappy_helicopter_best', String(best));
        const btn = document.getElementById('restart');
        btn.classList.remove('hidden');
        btn.focus();
      }
    } else if (state === 'ready') {
      // idle bob
      heli.y += Math.sin(Date.now()/400) * 0.4;
      heli.rot = Math.sin(Date.now()/900) * 0.12;
      heli.rotor += 0.2;
    } else if (state === 'gameover') {
      if (heli.y < BASE_H - 40) {
        heli.vy = Math.min(heli.vy + gravity, maxFall);
        heli.y += heli.vy;
        heli.rot = Math.atan2(heli.vy, 6);
        heli.rotor += 0.15;
      }
    }
  }

  function collidesWithBounds(){
    return (heli.y - heli.r < 0) || (heli.y + heli.r > BASE_H);
  }

  function collidesWithBuildings(){
    for (let b of buildings) {
      if (circleRectCollide(heli.x, heli.y, heli.r, b.x, 0, b.width, b.topH)) return true;
      if (circleRectCollide(heli.x, heli.y, heli.r, b.x, b.bottomY, b.width, b.bottomH)) return true;
    }
    return false;
  }

  function circleRectCollide(cx, cy, r, rx, ry, rw, rh){
    const closestX = clamp(cx, rx, rx + rw);
    const closestY = clamp(cy, ry, ry + rh);
    const dx = cx - closestX;
    const dy = cy - closestY;
    return (dx*dx + dy*dy) <= r*r;
  }

  function clamp(v, a, b){ return Math.max(a, Math.min(b, v)); }

  // Drawing
  function draw(){
    ctx.clearRect(0,0,BASE_W,BASE_H);

    drawSky();
    drawBuildings();

    // Ground line
    ctx.fillStyle = 'rgba(0,0,0,.08)';
    ctx.fillRect(0, BASE_H-24, BASE_W, 24);

    drawHelicopter(heli.x, heli.y, heli.r, heli.rot, heli.rotor);

    if (state === 'ready') {
      drawCenterText('Tap / Click / Space to fly', 28, '#0b1b2b', BASE_H*0.37);
      drawCenterText('Avoid the buildings!', 20, '#335c80', BASE_H*0.42);
    } else if (state === 'gameover') {
      drawGameOver();
    }
  }

  function drawSky(){
    // Gradient sky
    const sky = ctx.createLinearGradient(0,0,0,BASE_H);
    sky.addColorStop(0,'#b9e3ff');
    sky.addColorStop(1,'#e6f6ff');
    ctx.fillStyle = sky;
    ctx.fillRect(0,0,BASE_W,BASE_H);

    // Sun
    const sx = BASE_W*0.83, sy = BASE_H*0.18;
    const rg = ctx.createRadialGradient(sx, sy, 10, sx, sy, 80);
    rg.addColorStop(0,'#fff2a8');
    rg.addColorStop(1,'rgba(255,242,168,0)');
    ctx.fillStyle = rg;
    ctx.beginPath();
    ctx.arc(sx, sy, 120, 0, Math.PI*2);
    ctx.fill();

    // Clouds
    for (let c of clouds){
      drawCloud(c.x, c.y, c.w, c.h, c.a);
    }
  }

  function drawCloud(x,y,w,h,a){
    ctx.save();
    ctx.globalAlpha = a;
    ctx.fillStyle = '#ffffff';
    roundedRect(x, y, w, h, h*0.5);
    ctx.fill();
    // puffs
    ctx.beginPath();
    ctx.arc(x + w*0.2, y, h*0.7, 0, Math.PI*2);
    ctx.arc(x + w*0.45, y - h*0.2, h*0.9, 0, Math.PI*2);
    ctx.arc(x + w*0.7, y, h*0.75, 0, Math.PI*2);
    ctx.fill();
    ctx.restore();
  }

  function roundedRect(x,y,w,h,r){
    ctx.beginPath();
    ctx.moveTo(x+r, y);
    ctx.lineTo(x+w-r, y);
    ctx.quadraticCurveTo(x+w, y, x+w, y+r);
    ctx.lineTo(x+w, y+h-r);
    ctx.quadraticCurveTo(x+w, y+h, x+w-r, y+h);
    ctx.lineTo(x+r, y+h);
    ctx.quadraticCurveTo(x, y+h, x, y+h-r);
    ctx.lineTo(x, y+r);
    ctx.quadraticCurveTo(x, y, x+r, y);
    ctx.closePath();
  }

  function drawBuildings(){
    for (let b of buildings) {
      drawBuilding(b.x, 0, b.width, b.topH, true);
      drawBuilding(b.x, b.bottomY, b.width, b.bottomH, false);
    }
  }

  function drawBuilding(x, y, w, h, inverted){
    ctx.fillStyle = '#2f5b8f';
    ctx.fillRect(x, y, w, h);

    // Roof lip
    ctx.fillStyle = '#274c77';
    ctx.fillRect(x-2, inverted ? (y+h-6) : y, w+4, 6);

    // Windows
    const cols = 3, rows = Math.max(1, Math.floor(h/40));
    const padX = 10, padY = 10, cellW = (w - padX*2) / cols, cellH = (h - padY*2) / rows;
    ctx.fillStyle = '#e9f4ff';
    for (let r=0;r<rows;r++){
      for (let c=0;c<cols;c++){
        const wx = x + padX + c*cellW + 6;
        const wy = y + padY + r*cellH + 6;
        ctx.globalAlpha = 0.95 - Math.random()*0.25;
        ctx.fillRect(wx, wy, cellW - 12, cellH - 12);
        ctx.globalAlpha = 1;
      }
    }
    // Edge light/shadow
    ctx.fillStyle = 'rgba(255,255,255,.08)';
    ctx.fillRect(x+w-6, y, 6, h);
    ctx.fillStyle = 'rgba(0,0,0,.08)';
    ctx.fillRect(x, y, 4, h);
  }

  function drawHelicopter(x, y, r, rot, rotor){
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rot);

    // Body
    ctx.fillStyle = '#1f7ae0';
    ctx.beginPath();
    ctx.ellipse(0, 0, r*1.1, r*0.8, 0, 0, Math.PI*2);
    ctx.fill();

    // Cockpit (glass)
    ctx.fillStyle = '#cfeaff';
    ctx.beginPath();
    ctx.ellipse(r*0.3, -r*0.15, r*0.6, r*0.45, Math.PI/20, 0, Math.PI*2);
    ctx.fill();

    // Tail boom
    ctx.fillStyle = '#1b67be';
    roundedRect(-r*1.6, -r*0.18, r*1.7, r*0.36, r*0.18);
    ctx.fill();

    // Tail rotor mast
    ctx.fillStyle = '#163f76';
    ctx.fillRect(-r*2.0, -r*0.1, r*0.24, r*0.2);

    // Skids
    ctx.strokeStyle = '#163f76';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-r*0.9, r*0.8);
    ctx.quadraticCurveTo(-r*0.2, r*1.1, r*0.6, r*0.8);
    ctx.moveTo(-r*0.7, r*0.65);
    ctx.lineTo(r*0.4, r*0.65);
    ctx.stroke();

    // Main rotor mast
    ctx.fillStyle = '#163f76';
    ctx.fillRect(-3, -r*1.1, 6, r*0.9);

    // Main rotor blades
    ctx.save();
    ctx.translate(0, -r*1.1);
    ctx.rotate(rotor);
    ctx.fillStyle = '#2a2a2a';
    roundedRect(-r*1.5, -3, r*3.0, 6, 3);
    ctx.fill();
    ctx.restore();

    // Tail rotor blades (spinning disc illusion)
    ctx.save();
    ctx.translate(-r*2.0 + r*0.12, 0);
    ctx.rotate(rotor*2);
    ctx.fillStyle = 'rgba(42,42,42,0.9)';
    ctx.beginPath();
    ctx.ellipse(0, 0, r*0.28, r*0.12, 0, 0, Math.PI*2);
    ctx.fill();
    ctx.restore();

    ctx.restore();
  }

  function drawCenterText(text, size, color, y){
    ctx.fillStyle = 'rgba(255,255,255,.7)';
    roundedRect(30, y - size - 16, BASE_W - 60, size + 32, 16);
    ctx.fill();
    ctx.fillStyle = color;
    ctx.font = `bold ${size}px system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial`;
    ctx.textAlign = 'center';
    ctx.fillText(text, BASE_W/2, y);
  }

  function drawGameOver(){
    drawCenterText('Game Over', 40, '#0b1b2b', BASE_H*0.38);
    drawCenterText('Press Restart to try again', 22, '#335c80', BASE_H*0.44);
  }

  // HUD
  function updateHUD(){
    document.getElementById('score').textContent = score;
    document.getElementById('best').textContent = best;
  }

  // Input
  function onPrimary(){
    if (state === 'gameover') return;
    flap();
  }
  window.addEventListener('pointerdown', onPrimary, {passive:true});
  window.addEventListener('keydown', (e)=>{
    if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW'){
      e.preventDefault();
      onPrimary();
    }
    if (e.code === 'KeyR') restart();
  }, {passive:false});

  const restartBtn = document.getElementById('restart');
  restartBtn.addEventListener('click', (e)=>{
    e.stopPropagation(); // ensure window pointerdown doesn't interfere
    restart();
  });

  function restart(){
    restartBtn.classList.add('hidden');
    resetGame();
    state = 'playing';
  }

  // Main loop
  function loop(){
    update();
    draw();
    requestAnimationFrame(loop);
  }

  // Init
  resetGame();
  updateHUD();
  loop();
})();
