
// Flappy Boeing 747 - realistic buildings + remote plane image (Wikimedia)
// NOTE: plane image is loaded from Wikimedia Commons URL at runtime.
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const scoreEl = document.getElementById('score');
const startBtn = document.getElementById('startBtn');

let W, H;
function resize(){
  const rect = canvas.getBoundingClientRect();
  W = Math.floor(rect.width);
  H = Math.floor(rect.height);
  canvas.width = W * devicePixelRatio;
  canvas.height = H * devicePixelRatio;
  ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);
}
window.addEventListener('resize', resize);

let frames = 0;
let gameRunning = false;
let airplane;
let buildings = [];
let score = 0;
let speed = 2.4;

const GAP = 160;
const BUILD_INTERVAL = 100;

// Use Wikimedia Commons Boeing 747 PNG (side view with transparency)
// This loads remotely when the user opens index.html. If you want the image offline,
// download it and place plane.png alongside index.html, and change planeImg.src accordingly.
const planeImg = new Image();
planeImg.crossOrigin = 'anonymous';
planeImg.src = 'https://upload.wikimedia.org/wikipedia/commons/e/e5/An_Pan_Am_Boeing_747.png';
let imgLoaded = false;
planeImg.onload = () => { imgLoaded = true; };

function init(){
  resize();
  frames = 0;
  gameRunning = false;
  score = 0;
  buildings = [];
  airplane = { x: Math.floor(W*0.25), y: Math.floor(H*0.5), w: 140, h: 44, vel: 0, rot: 0 };
  drawBackground();
  drawAirplane(airplane.x, airplane.y, airplane.w, airplane.h, 0);
  scoreEl.textContent = 'Score: 0';
}

// physics
const GRAVITY = 0.4;
const FLAP = -8;

function startGame(){
  init();
  gameRunning = true;
  speed = 2.4;
  requestAnimationFrame(loop);
}

function endGame(){
  gameRunning = false;
  draw();
  ctx.save();
  ctx.globalAlpha = 0.9;
  ctx.fillStyle = 'rgba(0,0,0,0.45)';
  ctx.fillRect(0,0,W,H);
  ctx.fillStyle = 'white';
  ctx.font = '28px system-ui';
  ctx.textAlign = 'center';
  ctx.fillText('Game Over', W/2, H/2 - 10);
  ctx.font = '18px system-ui';
  ctx.fillText('Click Start to try again', W/2, H/2 + 22);
  ctx.restore();
}

function flap(){
  if(!gameRunning){ startGame(); return; }
  airplane.vel = FLAP;
  airplane.rot = -0.45;
}

function spawnBuilding(){
  // buildings vary in width and height for realism
  const minTop = 60;
  const maxTop = H - GAP - 80;
  const top = Math.floor(minTop + Math.random()*(Math.max(0,maxTop-minTop)));
  const width = 80 + Math.floor(Math.random()*80); // 80..160
  const colorSeed = Math.random();
  buildings.push({
    x: W + 40,
    top: top,
    bottom: H - (top + GAP),
    w: width,
    seed: colorSeed,
    passed: false
  });
}

function update(){
  frames++;
  if(frames % BUILD_INTERVAL === 0) spawnBuilding();
  airplane.vel += GRAVITY;
  airplane.y += airplane.vel;
  airplane.rot = Math.min(0.9, airplane.rot + 0.06);

  for(let i=buildings.length-1;i>=0;i--){
    buildings[i].x -= speed;
    if(buildings[i].x + buildings[i].w < -60){
      buildings.splice(i,1);
    } else if(!buildings[i].passed && buildings[i].x + buildings[i].w < airplane.x){
      buildings[i].passed = true;
      score++;
      scoreEl.textContent = 'Score: ' + score;
      if(score % 6 === 0) speed += 0.25;
    }
  }

  // ground/ceiling collision
  if(airplane.y + airplane.h/2 >= H || airplane.y - airplane.h/2 <= 0){
    endGame();
    return;
  }

  // collision with buildings (rectangle collision using airplane bounding box)
  const ax1 = airplane.x - airplane.w/2;
  const ax2 = airplane.x + airplane.w/2;
  const ay1 = airplane.y - airplane.h/2;
  const ay2 = airplane.y + airplane.h/2;
  for(const b of buildings){
    const bx1 = b.x;
    const bx2 = b.x + b.w;
    // top building rect: (bx1,0)-(bx2,b.top)
    if(!(ax2 < bx1 || ax1 > bx2 || ay2 < 0 || ay1 > b.top)){
      // overlap check
      if(!(ay1 > b.top || ay2 < 0)) { endGame(); return; }
    }
    // bottom building rect: (bx1, H-b.bottom)-(bx2, H)
    if(!(ax2 < bx1 || ax1 > bx2 || ay2 < H-b.bottom || ay1 > H)){
      if(!(ay1 > H || ay2 < H-b.bottom)) { endGame(); return; }
    }
  }
}

// Drawing utilities for realistic buildings
function drawBackground(){
  ctx.clearRect(0,0,W,H);
  // sky gradient
  const g = ctx.createLinearGradient(0,0,0,H);
  g.addColorStop(0,'#87ceeb');
  g.addColorStop(1,'#bfe6ff');
  ctx.fillStyle = g;
  ctx.fillRect(0,0,W,H);

  // sun
  const sunX = W * 0.85;
  const sunY = H * 0.18;
  const sRad = 36;
  const grad = ctx.createRadialGradient(sunX,sunY,6,sunX,sunY,sRad);
  grad.addColorStop(0,'rgba(255,250,200,0.98)');
  grad.addColorStop(1,'rgba(255,245,180,0.06)');
  ctx.fillStyle = grad;
  ctx.beginPath(); ctx.arc(sunX,sunY,sRad,0,Math.PI*2); ctx.fill();

  // subtle distant skyline
  drawDistantSkyline();
}

function drawDistantSkyline(){
  ctx.save();
  ctx.globalAlpha = 0.12;
  let x = -50 + (frames * 0.12 % 140);
  while(x < W + 100){
    const h = 20 + Math.abs(Math.sin(x*0.02))*70;
    ctx.fillRect(x, H - (h+30), 40, h);
    x += 60;
  }
  ctx.restore();
}

function drawBuildings(){
  for(const b of buildings){
    drawSingleBuilding(b);
  }
}

function drawSingleBuilding(b){
  const x = b.x;
  const w = b.w;
  // colors: pick from a palette based on seed
  const palettes = [
    ['#2f4f4f','#576b6b'],
    ['#403f4a','#6b6a78'],
    ['#3a3d2f','#5a5f45'],
    ['#5b3e2b','#8a6b53']
  ];
  const p = palettes[Math.floor(b.seed * palettes.length)];
  // top building
  const topH = b.top;
  const topGrad = ctx.createLinearGradient(x,0,x,topH);
  topGrad.addColorStop(0,p[0]);
  topGrad.addColorStop(1,p[1]);
  ctx.fillStyle = topGrad;
  roundRectFill(ctx, x, 0, w, topH, 6);

  // bottom building
  const bottomH = b.bottom;
  const botGrad = ctx.createLinearGradient(x, H-bottomH, x, H);
  botGrad.addColorStop(0,p[0]);
  botGrad.addColorStop(1,p[1]);
  ctx.fillStyle = botGrad;
  roundRectFill(ctx, x, H - bottomH, w, bottomH, 6);

  // windows grid (more realistic: rows/cols, some lit)
  drawBuildingWindows(x, 6, topH - 10, w - 12, 'top', b.seed);
  drawBuildingWindows(x, H - bottomH + 6, bottomH - 12, w - 12, 'bottom', b.seed + 0.3);

  // rooftop antenna / parapet details for top building
  ctx.fillStyle = 'rgba(0,0,0,0.12)';
  ctx.fillRect(x + 6, Math.max(0, topH - 12), Math.max(10, w - 12), 6);
}

function roundRectFill(ctx,x,y,w,h,r){
  ctx.beginPath();
  ctx.moveTo(x+r,y);
  ctx.arcTo(x+w,y,x+w,y+h,r);
  ctx.arcTo(x+w,y+h,x,y+h,r);
  ctx.arcTo(x,y+h,x,y,r);
  ctx.arcTo(x,y,x+w,y,r);
  ctx.closePath();
  ctx.fill();
}

function drawBuildingWindows(x,y,h,w,which,seed){
  if(h < 14 || w < 14) return;
  const colW = 12;
  const rowH = 14;
  const cols = Math.max(1, Math.floor(w / colW));
  const rows = Math.max(1, Math.floor(h / rowH));
  const spacingX = Math.floor((w - cols*10) / Math.max(1, cols-1));
  for(let c=0;c<cols;c++){
    for(let r=0;r<rows;r++){
      // deterministic-ish lit windows based on seed and position
      const rnd = Math.abs(Math.sin((seed*100 + c*7 + r*13))) ;
      const lit = rnd > 0.6;
      const wx = x + 6 + c*(10 + spacingX);
      const wy = y + 6 + r*(rowH);
      if(wy + 10 > y + h) continue;
      ctx.fillStyle = lit ? '#ffd' : '#1f2b2d'; // lit or dark windows
      ctx.fillRect(wx, wy, 8, 10);
      // small window highlight for lit windows
      if(lit){
        ctx.fillStyle = 'rgba(255,255,255,0.35)';
        ctx.fillRect(wx+1, wy+1, 4, 4);
      }
    }
  }
}

// draw airplane (image when loaded, otherwise fallback)
function drawAirplane(x,y,w,h,rot){
  ctx.save();
  ctx.translate(x,y);
  ctx.rotate(rot);
  if(imgLoaded){
    // maintain airplane aspect ratio; the source is long -> we draw scaled width = w
    const aspect = planeImg.width / Math.max(1, planeImg.height);
    const drawW = w;
    const drawH = h;
    ctx.drawImage(planeImg, -drawW/2, -drawH/2, drawW, drawH);
  } else {
    // fallback simple airplane shape
    ctx.fillStyle = '#ff7a00';
    roundRectFill(ctx, -w/2, -h/2, w, h, 6);
  }
  ctx.restore();
}

function draw(){
  drawBackground();
  drawBuildings();
  drawAirplane(airplane.x, airplane.y, airplane.w, airplane.h, Math.max(-0.9, Math.min(1.1, airplane.vel/8)));
  // HUD: score already shown in DOM
}

function loop(){
  if(!gameRunning) return;
  update();
  draw();
  requestAnimationFrame(loop);
}

// input
window.addEventListener('keydown', (e)=>{
  if(e.code === 'Space') { e.preventDefault(); flap(); }
});
canvas.addEventListener('pointerdown', (e)=>{ flap(); });
startBtn.addEventListener('click', ()=>{ startGame(); });

// init
init();
