// Snake game 21x21 using WASD controls with speed controls
(() => {
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const CELL_COUNT = 21;
  const CELL = canvas.width / CELL_COUNT;
  const BORDER_COLOR = 'rgb(32,128,32)';
  const CHECK1 = 'rgb(96,192,96)';
  const CHECK2 = 'rgb(128,208,96)';
  const SNAKE_COLOR = 'rgb(64,128,255)';
  const APPLE_COLOR = 'rgb(255,64,64)';

  const scoreEl = document.getElementById('score');
  const restartBtn = document.getElementById('restart');
  const slowBtn = document.getElementById('slow');
  const normalBtn = document.getElementById('normal');
  const fastBtn = document.getElementById('fast');

  let snake, dir, nextDir, apple, score, alive;
  let tickRate = 120;
  let loopId = null;

  function resetGame(){
    snake = [{x:10,y:10},{x:9,y:10},{x:8,y:10}];
    dir = {x:1,y:0};
    nextDir = {x:1,y:0};
    score = 0;
    alive = true;
    spawnApple();
    updateScore();
  }

  function updateScore(){ scoreEl.textContent = score; }

  function spawnApple(){
    const occupied = new Set(snake.map(p => p.x+','+p.y));
    let free = [];
    for(let y=0;y<CELL_COUNT;y++){
      for(let x=0;x<CELL_COUNT;x++){
        const k = x+','+y;
        if(!occupied.has(k)) free.push({x,y});
      }
    }
    if(free.length===0){ apple = null; return; }
    apple = free[Math.floor(Math.random()*free.length)];
  }

  function step(){
    if(!alive) return;
    dir = nextDir;
    const head = {x: snake[0].x + dir.x, y: snake[0].y + dir.y};
    if(head.x < 0 || head.x >= CELL_COUNT || head.y < 0 || head.y >= CELL_COUNT){
      alive = false; return;
    }
    for(const s of snake){ if(s.x===head.x && s.y===head.y){ alive=false; return; } }
    snake.unshift(head);
    if(apple && head.x===apple.x && head.y===apple.y){
      score += 1;
      updateScore();
      spawnApple();
    } else {
      snake.pop();
    }
  }

  function draw(){
    ctx.fillStyle = '#000';
    ctx.fillRect(0,0,canvas.width,canvas.height);

    const areaSize = CELL * CELL_COUNT;
    ctx.fillStyle = BORDER_COLOR;
    ctx.fillRect(-4, -4, areaSize + 8, areaSize + 8);

    for(let y=0;y<CELL_COUNT;y++){
      for(let x=0;x<CELL_COUNT;x++){
        const isEven = (x + y) % 2 === 0;
        ctx.fillStyle = isEven ? CHECK1 : CHECK2;
        ctx.fillRect(x*CELL, y*CELL, CELL, CELL);
      }
    }

    if(apple){
      const cx = apple.x*CELL + CELL/2;
      const cy = apple.y*CELL + CELL/2;
      const r = CELL * 0.36;
      ctx.beginPath();
      ctx.fillStyle = APPLE_COLOR;
      ctx.arc(cx, cy, r, 0, Math.PI*2);
      ctx.fill();
    }

    for(let p of snake){
      ctx.fillStyle = SNAKE_COLOR;
      ctx.fillRect(p.x*CELL+2, p.y*CELL+2, CELL-4, CELL-4);
    }

    if(!alive){
      ctx.fillStyle = 'rgba(0,0,0,0.55)';
      ctx.fillRect(0, 0, areaSize, areaSize);
      ctx.fillStyle = '#fff';
      ctx.font = '20px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Game Over', canvas.width/2, canvas.height/2 - 10);
      ctx.font = '14px system-ui, sans-serif';
      ctx.fillText('Press Restart (R)', canvas.width/2, canvas.height/2 + 16);
    }
  }

  function gameLoop(){
    step();
    draw();
  }

  function startLoop(){
    if(loopId) clearInterval(loopId);
    loopId = setInterval(gameLoop, tickRate);
  }

  function setSpeed(speed){
    if(speed === 'slow') tickRate = 200;
    if(speed === 'normal') tickRate = 120;
    if(speed === 'fast') tickRate = 70;
    startLoop();
  }

  restartBtn.addEventListener('click', () => { resetGame(); });
  slowBtn.addEventListener('click', () => setSpeed('slow'));
  normalBtn.addEventListener('click', () => setSpeed('normal'));
  fastBtn.addEventListener('click', () => setSpeed('fast'));

  window.addEventListener('keydown', (e) => {
    const k = e.key.toLowerCase();
    let desired = null;
    if(k === 'w') desired = {x:0,y:-1};
    if(k === 's') desired = {x:0,y:1};
    if(k === 'a') desired = {x:-1,y:0};
    if(k === 'd') desired = {x:1,y:0};
    if(desired){
      if(desired.x === -dir.x && desired.y === -dir.y) return;
      if(desired.x === -nextDir.x && desired.y === -nextDir.y) return;
      nextDir = desired;
      return;
    }
    if(k === 'r') resetGame();
    if(k === 'z') setSpeed('slow');
    if(k === 'x') setSpeed('normal');
    if(k === 'c') setSpeed('fast');
  });

  resetGame();
  spawnApple();
  setSpeed('normal');
})();