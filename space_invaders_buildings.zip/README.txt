Airplane vs Buildings — Mini Space Invaders clone
-----------------------------------------------

Files:
- index.html : the game page (open in a browser)
- style.css  : styling
- game.js    : game logic (canvas-based)

How to play:
- Move left/right: Left Arrow / Right Arrow or A / D.
- Shoot: Spacebar or click/tap the "Shoot" button.
- Buildings act as the invaders; your player is an airplane.
- Prevent buildings from reaching your runway; survive waves to increase difficulty.

This package is self-contained and uses canvas; no external assets needed.

Enjoy!