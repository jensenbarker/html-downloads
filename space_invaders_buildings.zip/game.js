// Airplane vs Buildings — simple Space Invaders-like game
// Player is an airplane; "aliens" are buildings.

// --- Setup
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const scoreEl = document.getElementById('score');
const livesEl = document.getElementById('lives');
const waveEl = document.getElementById('wave');
const message = document.getElementById('message');

const WIDTH = canvas.width;
const HEIGHT = canvas.height;

let keys = {};
let lastTime = 0;
let score = 0;
let lives = 3;
let wave = 1;
let gameOver = false;

// Player airplane
const player = {
  x: WIDTH / 2,
  y: HEIGHT - 40,
  w: 44,
  h: 16,
  speed: 260,
  cooldown: 0.25,
  cooldownTimer: 0
};

// Bullets fired by player
let bullets = [];

// Enemies: buildings
let enemies = [];
let enemyDirection = 1; // 1 right, -1 left
let enemySpeed = 30;
let enemyDrop = 18;
let enemySpacingX = 56;
let enemySpacingY = 46;
let rows = 4;
let cols = 8;

// Enemy bullets (rare)
let enemyBullets = [];

// Create formation
function spawnEnemies() {
  enemies = [];
  const offsetX = 60;
  const offsetY = 40;
  for (let r=0; r<rows; r++){
    for (let c=0; c<cols; c++){
      const bw = 36;
      const bh = 24;
      const x = offsetX + c * enemySpacingX;
      const y = offsetY + r * enemySpacingY;
      // Each enemy is a "building" with variable rooftop and windows
      enemies.push({
        x, y, w: bw, h: bh,
        hp: 1 + Math.floor(r/2),
        roofType: (c + r) % 3
      });
    }
  }
}

// --- Input
window.addEventListener('keydown', e => { keys[e.key.toLowerCase()] = true; if (e.key === ' '){ e.preventDefault(); }});
window.addEventListener('keyup', e => { keys[e.key.toLowerCase()] = false; });

document.getElementById('left').addEventListener('touchstart', e => { e.preventDefault(); keys['arrowleft'] = true; }, {passive:false});
document.getElementById('left').addEventListener('touchend', e => { keys['arrowleft'] = false; });
document.getElementById('right').addEventListener('touchstart', e => { e.preventDefault(); keys['arrowright'] = true; }, {passive:false});
document.getElementById('right').addEventListener('touchend', e => { keys['arrowright'] = false; });
document.getElementById('shoot').addEventListener('touchstart', e => { e.preventDefault(); shoot(); }, {passive:false});

// Mouse / click tap to shoot
document.getElementById('shoot').addEventListener('click', shoot);

// --- Game loop
spawnEnemies();

function update(dt){
  if (gameOver) return;

  // Player move
  if (keys['arrowleft'] || keys['a']) {
    player.x -= player.speed * dt;
  } else if (keys['arrowright'] || keys['d']) {
    player.x += player.speed * dt;
  }
  // clamp
  if (player.x < player.w/2) player.x = player.w/2;
  if (player.x > WIDTH - player.w/2) player.x = WIDTH - player.w/2;

  // Shooting
  player.cooldownTimer -= dt;
  if ((keys[' '] || keys['space'] || keys['x']) && player.cooldownTimer <= 0){
    shoot();
  }

  // Bullets
  bullets = bullets.filter(b => b.y > -10);
  bullets.forEach(b => {
    b.y -= b.speed * dt;
  });

  // Enemy movement: calc bounds
  let minX = Infinity, maxX = -Infinity;
  enemies.forEach(e => {
    if (e.x < minX) minX = e.x;
    if (e.x + e.w > maxX) maxX = e.x + e.w;
  });
  // change direction if hitting edges
  if (maxX + enemyDirection * enemySpeed * dt > WIDTH - 10 || minX + enemyDirection * enemySpeed * dt < 10) {
    enemyDirection *= -1;
    enemies.forEach(e => e.y += enemyDrop);
    // increase speed slightly
    enemySpeed *= 1.02;
  } else {
    enemies.forEach(e => e.x += enemyDirection * enemySpeed * dt);
  }

  // Enemy shooting (random)
  if (Math.random() < 0.01 + wave * 0.002) {
    const shooters = enemies.filter(Boolean);
    if (shooters.length > 0){
      const s = shooters[Math.floor(Math.random()*shooters.length)];
      enemyBullets.push({x: s.x + s.w/2, y: s.y + s.h + 6, vy: 140});
    }
  }

  // Enemy bullets update
  enemyBullets.forEach(b => b.y += b.vy * dt);
  enemyBullets = enemyBullets.filter(b => b.y < HEIGHT + 20);

  // Collisions: bullets -> enemies
  bullets.forEach((b, bi) => {
    enemies.forEach((e, ei) => {
      if (e && rectIntersect(b.x-2, b.y-6, 4, 8, e.x, e.y, e.w, e.h)) {
        // hit
        bullets[bi].y = -999; // remove
        e.hp -= 1;
        if (e.hp <= 0) {
          score += 10;
          enemies[ei] = null;
        } else {
          score += 5;
        }
      }
    });
  });
  enemies = enemies.filter(Boolean);

  // Collisions: enemy bullets -> player
  enemyBullets.forEach((b, bi) => {
    if (rectIntersect(b.x-3, b.y-6, 6, 10, player.x-player.w/2, player.y-player.h/2, player.w, player.h)) {
      enemyBullets[bi].y = HEIGHT + 999;
      loseLife();
    }
  });

  // Collisions: enemies reach player line
  enemies.forEach(e => {
    if (e && e.y + e.h >= player.y - 20) {
      // they reached your runway -> instant life lost
      loseLife();
      // push them back a bit
      e.y = -50;
    }
  });

  // Win condition for wave
  if (enemies.length === 0) {
    wave += 1;
    rows = Math.min(6, rows + (wave % 2));
    cols = Math.min(10, cols + (wave > 2 ? 1 : 0));
    enemySpeed = 30 + wave * 6;
    spawnEnemies();
  }

  // update HUD
  scoreEl.textContent = "Score: " + score;
  livesEl.textContent = "Lives: " + lives;
  waveEl.textContent = "Wave: " + wave;
}

function shoot(){
  if (player.cooldownTimer > 0) return;
  player.cooldownTimer = player.cooldown;
  bullets.push({x: player.x, y: player.y - 18, speed: 380});
}

// --- Helpers
function rectIntersect(x,y,w,h, X,Y,W,H){
  return !(x+w < X || x > X+W || y+h < Y || y > Y+H);
}

function loseLife(){
  lives -= 1;
  if (lives <= 0) {
    endGame();
  } else {
    // reset positions a bit
    player.x = WIDTH/2;
  }
}

function endGame(){
  gameOver = true;
  showMessage("Game Over", `Final score: ${score}. Tap to restart.`);
}

// --- Rendering
function draw(){
  // clear
  ctx.clearRect(0,0,WIDTH,HEIGHT);

  // runway lines at bottom
  ctx.save();
  ctx.fillStyle = "#071726";
  ctx.fillRect(0, HEIGHT-48, WIDTH, 48);
  // runway stripes
  ctx.fillStyle = "#101820";
  for (let i=0;i<WIDTH;i+=40){
    ctx.fillRect(i, HEIGHT-44, 24, 6);
  }
  ctx.restore();

  // draw enemies (buildings)
  enemies.forEach(e => drawBuilding(e));

  // draw enemy bullets
  enemyBullets.forEach(b => {
    ctx.fillStyle = "#ffce66";
    ctx.fillRect(b.x-3, b.y-6, 6, 10);
  });

  // draw player (airplane)
  drawAirplane(player.x, player.y);

  // draw player bullets
  bullets.forEach(b => {
    ctx.fillStyle = "#b7ecff";
    ctx.fillRect(b.x-2, b.y-8, 4, 10);
  });

  // HUD overlays optionally drawn here
}

// draw a stylized building
function drawBuilding(b){
  const x = b.x, y = b.y, w = b.w, h = b.h;
  // body
  const grad = ctx.createLinearGradient(x, y, x, y+h);
  grad.addColorStop(0, "#5b6b78");
  grad.addColorStop(1, "#2f3b44");
  ctx.fillStyle = grad;
  ctx.fillRect(x, y, w, h);
  // roof
  ctx.fillStyle = "#263238";
  if (b.roofType === 0) {
    ctx.fillRect(x-4, y-8, w+8, 8);
  } else if (b.roofType === 1) {
    ctx.beginPath();
    ctx.moveTo(x-4, y+4);
    ctx.lineTo(x + w/2, y-8);
    ctx.lineTo(x + w +4, y+4);
    ctx.closePath();
    ctx.fill();
  } else {
    ctx.fillRect(x, y-6, w, 6);
    // antenna
    ctx.fillRect(x + w/2 - 1, y - 26, 2, 20);
    ctx.beginPath();
    ctx.arc(x + w/2, y - 26, 3, 0, Math.PI*2);
    ctx.fill();
  }
  // windows grid
  ctx.fillStyle = "#9ad8ff";
  const cols = 3;
  const rowsw = 2 + Math.floor(h/12);
  const padx = 6;
  const pady = 6;
  for (let r=0;r<rowsw;r++){
    for (let c=0;c<cols;c++){
      const wx = x + padx + c * ((w - padx*2) / cols);
      const wy = y + pady + r * 12;
      ctx.fillRect(wx, wy, 8, 8);
    }
  }
}

// draw airplane as a small stylized craft
function drawAirplane(cx, cy){
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(1.1,1.1);
  // body
  ctx.beginPath();
  ctx.moveTo(-20, 6);
  ctx.quadraticCurveTo(-10, -8, 0, -10);
  ctx.quadraticCurveTo(12, -8, 24, 6);
  ctx.lineTo(20, 10);
  ctx.quadraticCurveTo(0, 4, -20, 6);
  ctx.closePath();
  ctx.fillStyle = "#d9f6ff";
  ctx.fill();
  // cockpit
  ctx.beginPath();
  ctx.ellipse(4, -2, 6, 4, 0, 0, Math.PI*2);
  ctx.fillStyle = "#2b4a5d";
  ctx.fill();
  // wings
  ctx.beginPath();
  ctx.moveTo(-4, 6);
  ctx.lineTo(-18, 14);
  ctx.lineTo(-6, 14);
  ctx.lineTo(0, 10);
  ctx.closePath();
  ctx.fillStyle = "#8fb8c9";
  ctx.fill();
  // tail
  ctx.beginPath();
  ctx.moveTo(18, -2);
  ctx.lineTo(26, -14);
  ctx.lineTo(18, -6);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

// --- Loop
function loop(ts){
  const dt = Math.min(0.04, (ts - lastTime) / 1000 || 0.016);
  lastTime = ts;
  update(dt);
  draw();
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);

// Restart / messages
function showMessage(title, text){
  message.classList.remove('hidden');
  message.innerHTML = `<div class="box"><h2>${title}</h2><p>${text}</p><p style="margin-top:12px"><button id="restart">Restart</button></p></div>`;
  document.getElementById('restart').addEventListener('click', () => { resetGame(); hideMessage(); });
  message.addEventListener('click', (e)=>{ if(e.target===message) { resetGame(); hideMessage(); }});
}

function hideMessage(){ message.classList.add('hidden'); message.innerHTML = ''; }

function resetGame(){
  score = 0;
  lives = 3;
  wave = 1;
  rows = 4;
  cols = 8;
  enemySpeed = 30;
  bullets = [];
  enemyBullets = [];
  gameOver = false;
  player.x = WIDTH/2;
  spawnEnemies();
}

// mobile: simple tap to move/shoot (optional)
canvas.addEventListener('touchstart', function(e){
  const t = e.touches[0];
  const rect = canvas.getBoundingClientRect();
  const x = t.clientX - rect.left;
  // if tap on left third -> move left briefly; right third -> right; center -> shoot
  if (x < rect.width/3) { keys['arrowleft'] = true; setTimeout(()=>keys['arrowleft']=false, 200); }
  else if (x > rect.width*2/3) { keys['arrowright'] = true; setTimeout(()=>keys['arrowright']=false, 200); }
  else { shoot(); }
}, {passive:true});