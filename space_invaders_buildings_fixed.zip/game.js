
// Airplane vs Buildings — Fixed textures and enemy movement
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const scoreEl = document.getElementById('score');
const livesEl = document.getElementById('lives');
const waveEl = document.getElementById('wave');
const message = document.getElementById('message');

const WIDTH = canvas.width;
const HEIGHT = canvas.height;

let keys = {};
let lastTime = 0;
let score = 0;
let lives = 3;
let wave = 1;
let gameOver = false;

// Player airplane
const player = {
  x: WIDTH / 2,
  y: HEIGHT - 48,
  w: 48,
  h: 18,
  speed: 300,
  cooldown: 0.05, // seconds between shots (fast)
  cooldownTimer: 0
};

let bullets = [];
let enemies = [];
let enemyDirection = 1;
let enemySpeed = 40; // px/sec
let enemyDrop = 20;
let rows = 4;
let cols = 8;
let enemySpacingX = 56;
let enemySpacingY = 48;

function spawnEnemies(){
  enemies = [];
  const offsetX = 60;
  const offsetY = 40;
  for(let r=0;r<rows;r++){
    for(let c=0;c<cols;c++){
      const bw = 40;
      const bh = 30;
      const x = offsetX + c * enemySpacingX;
      const y = offsetY + r * enemySpacingY;
      enemies.push({
        x, y, w: bw, h: bh,
        hp: 1 + Math.floor(r/2),
        roofType: (c + r) % 3,
        alive: true
      });
    }
  }
  // reset direction and speed relative to wave
  enemyDirection = 1;
  enemySpeed = 40 + (wave-1)*8;
}

spawnEnemies();

// Input
window.addEventListener('keydown', e => { keys[e.key.toLowerCase()] = true; if(e.key === ' ') e.preventDefault(); });
window.addEventListener('keyup', e => { keys[e.key.toLowerCase()] = false; });

document.getElementById('left').addEventListener('touchstart', e=>{ e.preventDefault(); keys['arrowleft'] = true; }, {passive:false});
document.getElementById('left').addEventListener('touchend', e=>{ keys['arrowleft'] = false; });
document.getElementById('right').addEventListener('touchstart', e=>{ e.preventDefault(); keys['arrowright'] = true; }, {passive:false});
document.getElementById('right').addEventListener('touchend', e=>{ keys['arrowright'] = false; });
document.getElementById('shoot').addEventListener('touchstart', e=>{ e.preventDefault(); shoot(); }, {passive:false});
document.getElementById('shoot').addEventListener('click', ()=>shoot());

// Game loop
function update(dt){
  if(gameOver) return;

  // Player movement
  if(keys['arrowleft'] || keys['a']) player.x -= player.speed * dt;
  if(keys['arrowright'] || keys['d']) player.x += player.speed * dt;
  if(player.x < player.w/2) player.x = player.w/2;
  if(player.x > WIDTH - player.w/2) player.x = WIDTH - player.w/2;

  // Shooting
  player.cooldownTimer -= dt;
  if((keys[' '] || keys['space'] || keys['x']) && player.cooldownTimer <= 0){
    shoot();
  }

  // Update bullets
  for(let i=bullets.length-1;i>=0;i--){
    const b = bullets[i];
    b.y -= b.speed * dt;
    // remove offscreen
    if(b.y < -10){ bullets.splice(i,1); continue; }
    // collision with enemies
    for(let j=0;j<enemies.length;j++){
      const e = enemies[j];
      if(e && e.alive && rectIntersect(b.x-2, b.y-6, 4, 10, e.x, e.y, e.w, e.h)){
        // hit
        bullets.splice(i,1);
        e.hp -= 1;
        if(e.hp <= 0){
          e.alive = false;
          score += 12;
        } else {
          score += 6;
        }
        break;
      }
    }
  }

  // Enemy movement
  let minX = Infinity, maxX = -Infinity;
  enemies.forEach(e=>{
    if(!e.alive) return;
    minX = Math.min(minX, e.x);
    maxX = Math.max(maxX, e.x + e.w);
  });
  // if no enemies (all dead) handle in win condition
  if(minX === Infinity){
    // wave cleared
    wave += 1;
    rows = Math.min(6, 4 + Math.floor((wave-1)/2));
    cols = Math.min(10, 6 + Math.floor((wave-1)/2));
    spawnEnemies();
    // small delay to let player prep (skip here)
  } else {
    // test future position for bounds
    const margin = 12;
    const futureMax = maxX + enemyDirection * enemySpeed * dt;
    const futureMin = minX + enemyDirection * enemySpeed * dt;
    if(futureMax > WIDTH - margin || futureMin < margin){
      enemyDirection *= -1;
      enemies.forEach(e => { if(e.alive) e.y += enemyDrop; });
      // slight speed increase per bounce
      enemySpeed *= 1.03;
    } else {
      enemies.forEach(e => { if(e.alive) e.x += enemyDirection * enemySpeed * dt; });
    }
  }

  // Enemies reaching player's lower area
  enemies.forEach(e=>{
    if(e.alive && (e.y + e.h >= player.y - 20)){
      // damage player and remove that enemy to avoid repeated triggers
      e.alive = false;
      loseLife();
    }
  });

  // Update HUD
  scoreEl.textContent = "Score: " + score;
  livesEl.textContent = "Lives: " + lives;
  waveEl.textContent = "Wave: " + wave;
}

function shoot(){
  if(player.cooldownTimer > 0) return;
  player.cooldownTimer = player.cooldown;
  bullets.push({x: player.x, y: player.y - 14, speed: 680});
}

// Helpers
function rectIntersect(x,y,w,h, X,Y,W,H){
  return !(x+w < X || x > X+W || y+h < Y || y > Y+H);
}

function loseLife(){
  lives -= 1;
  if(lives <= 0){
    endGame();
  } else {
    player.x = WIDTH/2;
    // small invuln could be added
  }
}

function endGame(){
  gameOver = true;
  showMessage("Game Over", `Final score: ${score}. Tap to restart.`);
}

// Rendering
function draw(){
  // clear & background gradient
  ctx.clearRect(0,0,WIDTH,HEIGHT);
  const bg = ctx.createLinearGradient(0,0,0,HEIGHT);
  bg.addColorStop(0,"#06202a");
  bg.addColorStop(1,"#03111a");
  ctx.fillStyle = bg;
  ctx.fillRect(0,0,WIDTH,HEIGHT);

  // runway
  ctx.save();
  ctx.fillStyle = "#071726";
  ctx.fillRect(0, HEIGHT-62, WIDTH, 62);
  ctx.fillStyle = "#0d2630";
  for(let i=0;i<WIDTH;i+=46){ ctx.fillRect(i, HEIGHT-58, 28, 8); }
  ctx.restore();

  // draw enemies (buildings)
  enemies.forEach(e=>{ if(e.alive) drawBuilding(e); });

  // bullets
  ctx.fillStyle = "#c9f4ff";
  bullets.forEach(b => ctx.fillRect(b.x-2, b.y-8, 4, 10));

  // player
  drawAirplane(player.x, player.y);

  // HUD (small overlay)
  ctx.fillStyle = "rgba(0,0,0,0.15)";
  ctx.fillRect(8,8,220,46);
  ctx.fillStyle = "#bfefff";
  ctx.font = "14px Arial";
  ctx.fillText("Score: " + score, 16, 26);
  ctx.fillText("Lives: " + lives + "   Wave: " + wave, 16, 44);
}

function drawBuilding(b){
  const x = b.x, y = b.y, w = b.w, h = b.h;
  // body gradient
  const g = ctx.createLinearGradient(x, y, x, y+h);
  g.addColorStop(0, "#6da0b9");
  g.addColorStop(1, "#294651");
  ctx.fillStyle = g;
  ctx.fillRect(x, y, w, h);

  // roof variations
  ctx.fillStyle = "#22343b";
  if(b.roofType === 0){
    ctx.fillRect(x-6, y-8, w+12, 8);
  } else if(b.roofType === 1){
    ctx.beginPath();
    ctx.moveTo(x-6, y+4);
    ctx.lineTo(x + w/2, y-12);
    ctx.lineTo(x + w +6, y+4);
    ctx.closePath();
    ctx.fill();
  } else {
    ctx.fillRect(x, y-6, w, 6);
    ctx.fillRect(x + w/2 - 1, y - 26, 2, 20);
    ctx.beginPath();
    ctx.arc(x + w/2, y - 26, 3, 0, Math.PI*2);
    ctx.fill();
  }

  // windows grid (randomized light)
  const cols = 3;
  const rowsw = Math.max(2, Math.floor((h-6)/10));
  ctx.fillStyle = "#e6f8ff";
  for(let r=0;r<rowsw;r++){
    for(let c=0;c<cols;c++){
      const wx = Math.round(x + 6 + c * ((w - 12) / cols));
      const wy = Math.round(y + 8 + r * 10);
      if(Math.random() > 0.15) ctx.fillRect(wx, wy, 8, 7);
    }
  }
}

function drawAirplane(cx, cy){
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(1,1);
  // fuselage
  ctx.beginPath();
  ctx.moveTo(-22, 6);
  ctx.quadraticCurveTo(-12, -8, 0, -12);
  ctx.quadraticCurveTo(14, -8, 26, 6);
  ctx.lineTo(20, 10);
  ctx.quadraticCurveTo(0, 4, -22, 6);
  ctx.closePath();
  ctx.fillStyle = "#e6fbff";
  ctx.fill();
  // cockpit
  ctx.beginPath();
  ctx.ellipse(4, -3, 6, 4, 0, 0, Math.PI*2);
  ctx.fillStyle = "#24464f";
  ctx.fill();
  // wings
  ctx.beginPath();
  ctx.moveTo(-6, 6);
  ctx.lineTo(-18, 14);
  ctx.lineTo(-6, 14);
  ctx.lineTo(0, 10);
  ctx.closePath();
  ctx.fillStyle = "#8fb8c9";
  ctx.fill();
  // tail
  ctx.beginPath();
  ctx.moveTo(18, -2);
  ctx.lineTo(26, -14);
  ctx.lineTo(18, -6);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

// Main loop
function loop(ts){
  const dt = Math.min(0.05, (ts - lastTime)/1000 || 0.016);
  lastTime = ts;
  update(dt);
  draw();
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);

// Message overlay for end/restart
function showMessage(title, text){
  message.classList.remove('hidden');
  message.innerHTML = `<div class="box"><h2>${title}</h2><p>${text}</p><p style="margin-top:12px"><button id="restart">Restart</button></p></div>`;
  document.getElementById('restart').addEventListener('click', ()=>{ resetGame(); hideMessage(); });
  message.addEventListener('click', (e)=>{ if(e.target===message){ resetGame(); hideMessage(); } });
}

function hideMessage(){ message.classList.add('hidden'); message.innerHTML = ''; }

function resetGame(){
  score = 0; lives = 3; wave = 1; rows = 4; cols = 8;
  bullets = []; enemies = [];
  player.x = WIDTH/2; player.cooldownTimer = 0;
  enemySpeed = 40;
  spawnEnemies();
  gameOver = false;
}

// simple canvas touch control: tap left/mid/right
canvas.addEventListener('touchstart', function(e){
  const t = e.touches[0];
  const rect = canvas.getBoundingClientRect();
  const x = t.clientX - rect.left;
  if(x < rect.width/3){ keys['arrowleft'] = true; setTimeout(()=>keys['arrowleft']=false, 160); }
  else if(x > rect.width*2/3){ keys['arrowright'] = true; setTimeout(()=>keys['arrowright']=false, 160); }
  else { shoot(); }
}, {passive:true});
