// Keyboard controls
document.addEventListener('keydown', (e)=>{
  if (e.repeat) return;
  switch(e.code){
    case 'ArrowLeft':  move(-1); break;
    case 'ArrowRight': move(1); break;
    case 'ArrowDown':  softDrop(); break;
    case 'ArrowUp':    rotatePlayer(1); break;
    case 'KeyQ':       rotatePlayer(-1); break;
    case 'KeyE':       rotatePlayer(1); break;
    case 'Space':      hardDrop(); break;
    case 'KeyC':       holdSwap(); break;
    case 'KeyR':       resetGame(); break;
  }
});
