// Core constants, colors, helpers, and 7-bag queue
const TILE = 20;
const COLS = 12, ROWS = 20;
const LEVEL_STEP = 10;
const MIN_INTERVAL = 200; // ms
const START_INTERVAL = 1000;

const colors = [ null,
  '#FF0D72', // 1
  '#0DC2FF', // 2
  '#0DFF72', // 3
  '#F538FF', // 4
  '#FF8E0D', // 5
  '#FFE138', // 6
  '#3877FF', // 7
];

function createMatrix(w, h){
  const m = [];
  while (h--) m.push(new Array(w).fill(0));
  return m;
}

function createPiece(type){
  switch (type){
    case 'T': return [[0,0,0],[1,1,1],[0,1,0]];
    case 'O': return [[2,2],[2,2]];
    case 'L': return [[0,3,0],[0,3,0],[0,3,3]];
    case 'J': return [[0,4,0],[0,4,0],[4,4,0]];
    case 'I': return [[0,5,0,0],[0,5,0,0],[0,5,0,0],[0,5,0,0]];
    case 'S': return [[0,6,6],[6,6,0],[0,0,0]];
    case 'Z': return [[7,7,0],[0,7,7],[0,0,0]];
  }
  return null;
}

// 7-bag
const PIECES = 'TJLOSZI';
let nextPieces = [];
function refillBag(){
  const bag = PIECES.split('');
  while (bag.length){
    const t = bag.splice(Math.random() * bag.length | 0, 1)[0];
    nextPieces.push(t);
  }
}
function ensureQueueMin(n=5){
  while (nextPieces.length < n) refillBag();
}
