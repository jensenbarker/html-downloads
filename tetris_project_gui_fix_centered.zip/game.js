// Main loop & overlay
function triggerGameOver(){
  isGameOver = true;
  document.getElementById('finalScore').innerText = player.score;
  document.getElementById('gameOverOverlay').style.display = 'flex';
  if (player.score > highScore){
    highScore = player.score;
    document.getElementById('highScore').innerText = highScore;
  }
}

function resetGame(){
  for (let y=0; y<arena.length; y++) arena[y].fill(0);
  player.score = 0; player.level = 1; player.lines = 0;
  dropInterval = START_INTERVAL; dropCounter = 0; lastTime = 0;
  holdPiece = null; canHold = true; nextPieces = [];
  ensureQueueMin(5);
  isGameOver = false;
  document.getElementById('gameOverOverlay').style.display = 'none';
  spawnNew();
  drawNext();
  drawHold();
  updateHUD();
  requestAnimationFrame(update);
}

document.getElementById('restartButton').addEventListener('click', resetGame);

function update(time=0){
  if (isGameOver) return;
  const delta = time - lastTime;
  lastTime = time;
  dropCounter += delta;
  if (dropCounter > dropInterval) softDrop();
  draw();
  requestAnimationFrame(update);
}

// Boot
ensureQueueMin(5);
spawnNew();
updateHUD();
requestAnimationFrame(update);
