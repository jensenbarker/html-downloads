// Player state & actions
const player = {
  pos: {x:0, y:0},
  matrix: null,
  type: null,
  score: 0,
  level: 1,
  lines: 0,
};

let dropCounter = 0;
let dropInterval = START_INTERVAL;
let lastTime = 0;
let isGameOver = false;
let highScore = 0;

let holdPiece = null;
let canHold = true;

function spawnNew(){
  ensureQueueMin(5);
  const type = nextPieces.shift();
  player.type = type;
  player.matrix = createPiece(type);
  player.pos.y = 0;
  player.pos.x = (COLS/2|0) - (player.matrix[0].length/2|0);
  canHold = true;

  if (collide(arena, player)){
    triggerGameOver();
  }
  drawNext();
  drawHold();
  updateHUD();
}

function softDrop(){
  if (isGameOver) return;
  player.pos.y++;
  if (collide(arena, player)){
    player.pos.y--;
    merge(arena, player);
    arenaSweep();
    spawnNew();
  }
  dropCounter = 0;
}

function hardDrop(){
  if (isGameOver) return;
  while (!collide(arena, player)) player.pos.y++;
  player.pos.y--;
  merge(arena, player);
  arenaSweep();
  spawnNew();
  dropCounter = 0;
}

function move(dir){
  if (isGameOver) return;
  player.pos.x += dir;
  if (collide(arena, player)) player.pos.x -= dir;
}

function rotate(matrix, dir){
  for (let y=0; y<matrix.length; y++){
    for (let x=0; x<y; x++){
      [matrix[x][y], matrix[y][x]] = [matrix[y][x], matrix[x][y]];
    }
  }
  if (dir>0) matrix.forEach(r=>r.reverse());
  else matrix.reverse();
}

function rotatePlayer(dir){
  if (isGameOver) return;
  const pos = player.pos.x;
  let offset = 1;
  rotate(player.matrix, dir);
  while (collide(arena, player)){
    player.pos.x += offset;
    offset = -(offset + (offset > 0 ? 1 : -1));
    if (offset > player.matrix[0].length){
      rotate(player.matrix, -dir);
      player.pos.x = pos;
      return;
    }
  }
}

function holdSwap(){
  if (isGameOver || !canHold) return;
  const currentType = player.type;
  if (!holdPiece){
    holdPiece = currentType;
    spawnNew();
  } else {
    const temp = holdPiece;
    holdPiece = currentType;
    player.type = temp;
    player.matrix = createPiece(player.type);
    player.pos.y = 0;
    player.pos.x = (COLS/2|0) - (player.matrix[0].length/2|0);
  }
  canHold = false;
  drawHold();
  drawNext();
}
