// All draw routines & canvases
const arenaCanvas = document.getElementById('tetris');
const ctx = arenaCanvas.getContext('2d');
ctx.scale(TILE, TILE); // <- important: square cells

const nextCanvas = document.getElementById('preview');
const nextCtx = nextCanvas.getContext('2d');
nextCtx.scale(TILE, TILE);

const holdCanvas = document.getElementById('hold');
const holdCtx = holdCanvas.getContext('2d');
holdCtx.scale(TILE, TILE);

function drawGrid(){
  ctx.fillStyle = '#000';
  ctx.fillRect(0,0,arenaCanvas.width, arenaCanvas.height);
  ctx.beginPath();
  ctx.strokeStyle = 'rgba(255,255,255,0.06)';
  for (let x=0; x<=COLS; x++){ ctx.moveTo(x,0); ctx.lineTo(x,ROWS); }
  for (let y=0; y<=ROWS; y++){ ctx.moveTo(0,y); ctx.lineTo(COLS,y); }
  ctx.stroke();
}

function drawMatrix(matrix, offset, override=null, context=ctx){
  if (!matrix) return;
  matrix.forEach((row,y)=>{
    row.forEach((val,x)=>{
      if (val !== 0){
        context.fillStyle = override || colors[val];
        context.fillRect(x + offset.x, y + offset.y, 1, 1);
      }
    });
  });
}

function drawGhost(){
  if (!player.matrix) return;
  const ghost = { pos:{x:player.pos.x, y:player.pos.y}, matrix: player.matrix };
  while (!collide(arena, ghost)) ghost.pos.y++;
  ghost.pos.y--;
  drawMatrix(ghost.matrix, ghost.pos, 'rgba(255,255,255,0.25)');
}

function draw(){
  drawGrid();
  drawMatrix(arena, {x:0,y:0});
  drawGhost();
  drawMatrix(player.matrix, player.pos);
}

function drawNext(){
  ensureQueueMin(5);
  nextCtx.fillStyle = '#000';
  nextCtx.fillRect(0,0,nextCanvas.width,nextCanvas.height);
  for (let i=0; i<5; i++){
    const t = nextPieces[i];
    if (!t) continue;
    drawMatrix(createPiece(t), {x:1, y:i*4}, null, nextCtx);
  }
}

function drawHold(){
  holdCtx.fillStyle = '#000';
  holdCtx.fillRect(0,0,holdCanvas.width,holdCanvas.height);
  if (holdPiece){
    drawMatrix(createPiece(holdPiece), {x:1, y:1}, null, holdCtx);
  }
}

function updateHUD(){
  document.getElementById('score').innerText = player.score;
  document.getElementById('level').innerText = player.level;
  if (player.score > highScore){
    highScore = player.score;
    document.getElementById('highScore').innerText = highScore;
  }
}
